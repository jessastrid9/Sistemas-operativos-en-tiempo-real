#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> /*sleep()*/

void procesoq(int N);
void procesop(int N);


int wantp=0;
int wantq=0;
int turn=1;
int N=0;
int salir=0;
int TRUE=1;

int main(int argc,char *argv[])
{
	          pthread_t thrd1,thrd2;
		              int ret;
			  /*Crea el primer hilo*/
 ret=pthread_create(&thrd1,NULL,(void*)procesop,(void*)&N);
			 if(ret){
				 perror("pthread_create: task1");
				 exit(EXIT_FAILURE);}
								                                   /*Crea el segundo hilo*/                                     	 ret=pthread_create(&thrd2,NULL,(void*)procesoq,(void*)&N);
			  if(ret){	                                       perror("pthread_create: task2");
	 exit(EXIT_FAILURE);
		 }					                                   exit(EXIT_SUCCESS);
}/* end main()*/

void procesop(int N)
{
	       
		  
			          while(TRUE){
		 printf("PROCESO P SECCION NO CRITICA\n");				  wantp=1;
	       	 while(wantq){
                if (turn==2){
		wantp=0;
		while(!(turn==1))
		wantp=1;
		}
		 }	
	       	printf("PROCESO P SECCION CRITICA\n");					 turn=2	;
	wantp=0;							                                        }   }
void procesoq(int N)
{
        
         while(TRUE){
  printf("PROCESO Q SECCION NO CRITICA\n");
	wantq=1;
  while(wantp)	{     									 if (turn==1)    if (turn==1) {
	  wantq=0;
	  while(!(turn==2));		    
	  wantq=1;
	}
		  }
 printf("PROCESO Q SECCION CRITICA\n");
		turn=1;
	  	 wantq=0;						          }
}



