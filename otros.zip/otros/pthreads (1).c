#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> /*sleep()*/

void task1(int *counter);
void task2(int *counter);
void cleanup(int counter1,int counter2);

int N=0;
 int wantp=0;
 int wantq = 0;
 int turn = 1;

int main(int argc,char *argv[])
{
	  pthread_t thrd1,thrd2;
	    int ret;
	      
	      /*Crea el primer hilo*/
	      ret=pthread_create(&thrd1,NULL,(void*)task1,(void*)&N);
	        if(ret){
			    perror("pthread_create: task1");
			        exit(EXIT_FAILURE);
				  }
		  /*Crea el segundo hilo*/
		  ret=pthread_create(&thrd2,NULL,(void*)task2,(void*)&N);
		    if(ret){
			        perror("pthread_create: task2");
				    exit(EXIT_FAILURE);
				      }

		      pthread_join(thrd2,NULL);
		        pthread_join(thrd1,NULL);

			    exit(EXIT_SUCCESS);
}/* end main()*/

void task1(int *counter)
	{
	  while(*counter<10){
		  printf("PROCESO P SECCION NO CRITICA\n");
	         printf("N=%d\n",N);
		  (*counter)++;
		  wantp=1;
		  while((turn =!1));
		  wantp=1;
	     		 }

		
printf("PROCESO P SECCION CRITICA\n");
N=N+1;
turn=2;
wantp=0;
}
void task2(int *counter)
{
	*counter=0;
	  while(*counter<10){
	        printf("PROCESO Q SECCION NO CRITICA\n");
	        printf("N=%d\n",N);
	       	(*counter)++;
		wantq=1;
		while (wantp){
			if (turn==1)
			{
				wantq=0;
				while (!(turn==2));
				wantq =1;
			    }
}
 
printf("PROCESO Q SECCION CRITICA\n");
printf("N=%d",N);
N=N+1;
turn=1;
wantq=0;
}
}



